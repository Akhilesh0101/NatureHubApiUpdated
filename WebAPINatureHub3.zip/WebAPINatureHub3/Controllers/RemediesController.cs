﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPINatureHub3.Models;

namespace WebAPINatureHub3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RemediesController : ControllerBase
    {
        private readonly NatureHub3Context _context;

        public RemediesController(NatureHub3Context context)
        {
            _context = context;
        }

        // GET: api/Remedies
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Remedy>>> GetRemedies()
        {
            return await _context.Remedies.ToListAsync();
        }

        // GET: api/Remedies/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Remedy>> GetRemedy(int id)
        {
            var remedy = await _context.Remedies.FindAsync(id);

            if (remedy == null)
            {
                return NotFound();
            }

            return remedy;
        }

        // PUT: api/Remedies/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize]

        public async Task<IActionResult> PutRemedy(int id, Remedy remedy)
        {
            if (id != remedy.RemedyId)
            {
                return BadRequest();
            }

            _context.Entry(remedy).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RemedyExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Remedies
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize]

        public async Task<ActionResult<Remedy>> PostRemedy(Remedy remedy)
        {
            _context.Remedies.Add(remedy);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetRemedy", new { id = remedy.RemedyId }, remedy);
        }

        // DELETE: api/Remedies/5
        [HttpDelete("{id}")]
        [Authorize]

        public async Task<IActionResult> DeleteRemedy(int id)
        {
            var remedy = await _context.Remedies.FindAsync(id);
            if (remedy == null)
            {
                return NotFound();
            }

            _context.Remedies.Remove(remedy);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool RemedyExists(int id)
        {
            return _context.Remedies.Any(e => e.RemedyId == id);
        }
    }
}
