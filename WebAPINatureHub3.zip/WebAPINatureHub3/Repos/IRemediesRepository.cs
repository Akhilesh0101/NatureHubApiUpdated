﻿using WebAPINatureHub3.Models;

namespace WebAPINatureHub3.Repos
{
    public interface IRemediesRepository
    {
        IEnumerable<Remedy> GetAll();
        Remedy GetById(int id);
        void Add(Remedy remedy);
        void Update(Remedy remedy);
        void Delete(int id);
    }
}
